import numpy as np
arr=np.zeros((128,), dtype=int)
print(arr)
print(type(-0.05143594))