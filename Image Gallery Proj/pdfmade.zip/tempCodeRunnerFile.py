import numpy as np
arr=np.zeros((128,), dtype=int)
print(arr)